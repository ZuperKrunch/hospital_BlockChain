# RuangSehat Hospital dApp

Prototipe kuliah dengan dashboard Admin, Dokter, dan Pasien. Gunakan data fiktif. UI menggunakan halaman terpisah per menu, dengan jadwal dalam WIB.

## Coba dari PowerShell

Perlu **Node.js 24**. Buka terminal di folder yang berisi `package.json`.

```powershell
npm.cmd ci
npm.cmd run demo
```

Buka **http://localhost:5173/**. Mode demo mengaktifkan API, database SQLite, dan blockchain lokal Ganache dengan kontrak yang sama. Profil, jadwal, dan versi catatan tersimpan di `data/demo`. Akun demo bersifat fiktif dan hanya dipakai pada server lokal. Mode ini tidak memakai MetaMask atau Sepolia ETH.

Di Termux, salin folder hasil ekstrak ke home Termux (`~/`), lalu jalankan `npm ci` dan `npm run demo` dari folder yang berisi `package.json`. Gunakan Node.js 24 dengan modul bawaan `node:sqlite`. Cek ketersediaannya dengan `node -e "require('node:sqlite')"` sebelum menjalankan server.

1. Masuk sebagai **dr. Arga**. Buka **Rekam Medis** dan pilih appointment Alex yang sudah check-in. Tulis contoh pemeriksaan fiktif. **Revisi catatan** membuat versi berikutnya, sedangkan **Nonaktifkan** mencatat status penonaktifan dan menyimpan versi terdahulu.
2. Keluar dan masuk sebagai **Alex** untuk melihat record dan versi yang sudah punya bukti. Buka **Izin Dokter** jika ingin memberi atau mencabut akses Arga.
3. Masuk sebagai **Nadia**. **Appointment** menyediakan tambah, lihat, ubah waktunya, dan hapus jadwal yang belum punya tagihan atau pemeriksaan. Untuk penjadwalan, copy wallet dari **Pengguna & Peran** atau **Profil Saya**. Di **Kasir & Pembayaran**, admin dapat membuat, melihat, mengubah, dan menghapus tagihan yang belum dibayar. Tagihan lunas bisa dibatalkan dengan status **Dibatalkan** agar jejaknya tersimpan. Admin dan pasien terkait bisa mencetak struk dari tagihan berstatus **Lunas**.
4. **Profil Saya** mendukung tambah, lihat, ubah, dan hapus profil off-chain. Untuk dokter, profil yang punya spesialisasi tampil di **Direktori Dokter**.
5. Untuk demo **Akses Darurat**, admin daftarkan browser di menu IGD. Setelah itu admin atau dokter bisa membuka ringkasan 30 menit dari browser terdaftar. Untuk alasan **Lainnya**, isi laporan setelah akses ditutup atau berakhir.

Appointment contoh memiliki waktu yang nyata sejak data demo pertama dibuat. Setelah lewat, buat kunjungan baru lewat Admin. Untuk mulai dari data kosong, hentikan demo dan pindahkan folder `data/demo` sebagai cadangan, lalu jalankan ulang.

## Pembagian data dan akses

| Data | Penyimpanan | Isi |
| --- | --- | --- |
| Profil dokter dan pasien | SQLite | Nama, spesialisasi, poli, bio, kontak, tanggal lahir, dan jenis kelamin sesuai peran |
| Appointment dan akses darurat | SQLite | Pihak terkait, jadwal, check-in, alasan akses, dan laporan |
| Isi rekam medis dan riwayat versi | SQLite | Keluhan, diagnosis, riwayat, obat, hasil pemeriksaan, dan salt |
| Tagihan dan struk | SQLite | Nomor struk, rincian, nominal, status, dan waktu pencatatan |
| Role dan izin | Kontrak | Alamat wallet, role, dan status izin pasien ke dokter |
| Bukti versi rekam medis | Kontrak | ID acak, nomor versi, komitmen hash, dan status aktif |

- **SQLite server** menyimpan profil, jadwal, tagihan, rekam medis, dan detail audit IGD. Endpoint mengecek sesi wallet dan peran. Pasien hanya membaca data klinis miliknya. Admin hanya menerima nomor kontak dari daftar appointment yang masih terjadwal setidaknya 30 menit setelah waktu mulai.
- **Blockchain** menyimpan role, persetujuan pasien, serta ID acak, nomor versi, komitmen SHA-256 dan status aktif dari tiap record. Komitmen dihitung dari data versi dan salt acak yang disimpan off-chain. Transaksi publik tetap mengungkap alamat wallet, aktivitas role/izin, dan waktu publikasi. Event izin memuat pasangan wallet pasien dan dokter.
- Dokter yang ditugaskan membutuhkan persetujuan pasien, check-in, dan jendela waktu yang aktif. Saat jadwal berakhir atau admin menandai selesai, riwayat lengkap ditutup. Dokter masih boleh mengisi catatan appointment tersebut sampai **30 menit setelah jam selesai terjadwal**. Pembatalan atau pencabutan izin menghentikan akses dari API. Aplikasi menampilkan hitung mundur, dan server memutuskan akses berdasarkan waktu server.
- Kontrak hanya menerima bukti dari wallet publisher. Wallet publisher membayar gas bukti, sedangkan perubahan role dan izin dilakukan oleh wallet pengguna terkait. Apabila transaksi tertunda, versi tetap tersimpan sebagai pending dan baru terlihat sebagai terkonfirmasi setelah API menemukan bukti yang cocok. **Sinkronkan bukti** dapat mencoba lagi bila belum ada transaksi yang diterima atau transaksi diketahui gagal. Bila ada transaksi yang sudah terkirim, sinkronisasi menunggu statusnya untuk menghindari pengiriman ganda. Operasikan satu instance API per database/publisher.
- Terminal IGD diikat ke token browser yang didaftarkan admin. Audit darurat berada di database. Akses dibatasi pada ringkasan dan ditutup saat waktu habis, sesi ditutup, atau token terminal dicabut. Token browser dapat dipindahkan bila browser/profilnya disalin. Ini bukan identitas perangkat fisik.
- Database prototipe memakai SQLite biasa. Simpan file database dan cadangannya di penyimpanan privat. Sebelum mempertimbangkan data sungguhan, perlu peninjauan keamanan, enkripsi penyimpanan, pengelolaan kunci, pembatasan permintaan produksi, cadangan serta kontrol operasional.

## Pemetaan syarat tugas

| Syarat | Alur yang dapat didemokan |
| --- | --- |
| Tiga role | Admin menetapkan role. Dokter menangani kunjungan dan menulis rekam medis. Pasien memberi izin dokter dan melihat datanya sendiri. |
| Login wallet | Pada mode Sepolia, akun masuk dengan tanda tangan MetaMask yang diverifikasi API. Mode demo memakai akun fiktif preset. |
| CRUD on-chain | Pembuatan catatan menulis bukti pertama, pembacaan menggunakan bukti versi, dan revisi menulis bukti baru. Penonaktifan menulis status `active=false` sebagai soft delete. Bukti versi yang sudah diterbitkan tetap ada. |
| CRUD off-chain | Tambah, lihat, ubah, dan hapus profil dari **Profil Saya**. Admin bisa mendemokan CRUD tagihan yang belum dibayar dari **Kasir & Pembayaran**. |

## Live dengan MetaMask dan Sepolia

1. Deploy **`contracts/RuangSehat.sol`** dari wallet Admin di Remix. Gunakan Solidity 0.8.30, optimizer 200 dan EVM Paris agar sesuai pengaturan build. Role dan izin perlu ditetapkan kembali untuk deployment ini. Isi rekam medis yang pernah dikirim ke kontrak lama di Sepolia tetap publik. Mulai database versi ini dengan data fiktif baru.
2. Siapkan **wallet khusus publisher lokal**, terpisah dari Admin dan pengguna. Isi saldo Sepolia ETH seperlunya. Di Remix, dari akun Admin jalankan `setPublisher` dengan **alamat publik** wallet tersebut. Fungsi ini mendaftarkan wallet yang boleh menulis hash.
3. Copy `.env.example` menjadi `.env`. Isi `RPC_URL` Sepolia, `CONTRACT_ADDRESS` yang baru, dan `PUBLISHER_PRIVATE_KEY` di server. Jangan taruh private key di `VITE_*`, frontend, atau repository.
4. Untuk web dan API di komputer sendiri, set `APP_ORIGIN=http://localhost:5173` lalu jalankan `npm.cmd run dev`. Buka alamat persis itu. MetaMask meminta tanda tangan ketika masuk dan konfirmasi transaksi ketika menetapkan role atau izin.
5. Untuk GitHub Pages, host API dengan `npm run api` pada server Node 24 ber-HTTPS dengan volume persisten untuk `DATABASE_PATH`. Set `APP_ORIGIN=https://x4t0r1.github.io` (origin tanpa jalur repo). Isi **repository variable** GitHub Actions `VITE_API_URL` dengan alamat HTTPS API tanpa `/api`. Build GitHub Pages memakai jalur `/Blockchain/`. Jalankan workflow **Deploy Hospital Web** dari tab Actions setelah API siap. Jangan jalankan mode demo di server publik.

Ganti akun langsung dari MetaMask. Wallet yang belum masuk perlu tanda tangan satu kali. Saat kembali ke wallet yang sudah masuk, dashboard terbuka otomatis selama sesi wallet itu masih berlaku di tab yang sama. Tombol **Keluar** mengakhiri sesi wallet aktif.

Pengujian lokal: `npm.cmd test`, `npm.cmd run lint`, `npm.cmd run build`. Tes integrasi memakai SQLite sementara dan transaksi Ganache. Setup Sepolia serta hosting API perlu dilakukan pada infrastruktur yang akan digunakan.

Rujukan: [ERC-4361 · Sign-In with Ethereum](https://eips.ethereum.org/EIPS/eip-4361) · [Node.js SQLite](https://nodejs.org/download/release/v24.22.1/docs/api/sqlite.html).
